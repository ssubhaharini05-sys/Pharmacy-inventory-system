"""
Database configuration and management for Pharmacy Inventory Management System.
Uses SQLite only (pharmacy.db).
Automatically creates all required tables and populates sample data on first run.
"""

import sqlite3
import os
from datetime import date, timedelta
from werkzeug.security import generate_password_hash

# Path to the SQLite database file
DB_NAME = "pharmacy.db"
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), DB_NAME)


def get_db_connection():
    """
    Establish and return a connection to the SQLite database.
    Enables foreign key constraints and dictionary-like row access.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """
    Create all required tables automatically if they do not already exist.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Users table (Admin and Staff)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin', 'staff')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. Medicines table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS medicines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_name TEXT NOT NULL,
        company TEXT NOT NULL,
        category TEXT NOT NULL,
        batch_no TEXT NOT NULL,
        expiry_date DATE NOT NULL,
        price REAL NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 0,
        reorder_level INTEGER NOT NULL DEFAULT 10,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 3. Suppliers table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supplier_name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 4. Purchases table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_id INTEGER NOT NULL,
        supplier_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        purchase_price REAL NOT NULL,
        purchase_date DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE CASCADE,
        FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE CASCADE
    );
    """)

    # 5. Sales table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_id INTEGER NOT NULL,
        customer_name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        selling_price REAL NOT NULL,
        total_amount REAL NOT NULL,
        sale_date DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE CASCADE
    );
    """)

    conn.commit()
    conn.close()

    # Populate initial sample data if database is fresh
    seed_sample_data()


def seed_sample_data():
    """
    Populate sample data automatically if the database has no records.
    Ensures default admin/staff accounts, sample suppliers, medicines,
    purchases, and sales for the last 7 days exist.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if users already exist
    cursor.execute("SELECT COUNT(*) as count FROM users")
    if cursor.fetchone()['count'] == 0:
        # Default Admin: admin / admin123
        admin_pass = generate_password_hash("admin123")
        cursor.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            ("admin", admin_pass, "admin")
        )

        # Default Staff: staff / staff123
        staff_pass = generate_password_hash("staff123")
        cursor.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            ("staff", staff_pass, "staff")
        )

    # Check if suppliers exist
    cursor.execute("SELECT COUNT(*) as count FROM suppliers")
    if cursor.fetchone()['count'] == 0:
        suppliers_data = [
            ("MedLife Pharma Distributors", "+1 800-555-0199", "orders@medlifepharma.com", "120 Healthcare Blvd, New York, NY"),
            ("Apex Medical Supplies", "+1 800-555-0144", "contact@apexmed.com", "45 Global Logistics Way, Chicago, IL"),
            ("BioCare Healthcare Labs", "+1 800-555-0188", "support@biocarelabs.com", "78 Pharma Park, San Francisco, CA")
        ]
        cursor.executemany(
            "INSERT INTO suppliers (supplier_name, phone, email, address) VALUES (?, ?, ?, ?)",
            suppliers_data
        )

    # Check if medicines exist
    cursor.execute("SELECT COUNT(*) as count FROM medicines")
    if cursor.fetchone()['count'] == 0:
        today = date.today()

        # Dynamic sample medicines:
        # - 2 Low stock (< or == reorder_level)
        # - 2 Expiring within 30 days
        # - 2 Already Expired
        # - 6 Healthy active medicines
        medicines_data = [
            # Low stock 1 (Quantity 4 <= reorder_level 15)
            ("Amoxicillin 500mg", "Pfizer Inc.", "Antibiotics", "AMX-8921",
             (today + timedelta(days=120)).isoformat(), 15.50, 4, 15),

            # Low stock 2 (Quantity 0 -> Out of Stock, reorder 20)
            ("Paracetamol 650mg", "GlaxoSmithKline", "Analgesics", "PCM-4402",
             (today + timedelta(days=200)).isoformat(), 5.00, 0, 20),

            # Expiring soon 1 (Expiring in 9 days)
            ("Azithromycin 250mg", "Cipla Ltd", "Antibiotics", "AZI-1109",
             (today + timedelta(days=9)).isoformat(), 22.00, 35, 10),

            # Expiring soon 2 (Expiring in 21 days)
            ("Cetirizine 10mg", "Dr. Reddy's", "Antihistamine", "CET-9943",
             (today + timedelta(days=21)).isoformat(), 8.75, 50, 15),

            # Expired 1 (Expired 20 days ago)
            ("Ibuprofen 400mg", "Abbott Laboratories", "Pain Relief", "IBU-3012",
             (today - timedelta(days=20)).isoformat(), 12.00, 18, 10),

            # Expired 2 (Expired 45 days ago)
            ("Cough Syrup DX 100ml", "Sun Pharma", "Respiratory", "CSD-6651",
             (today - timedelta(days=45)).isoformat(), 9.50, 12, 5),

            # Healthy stock medicines
            ("Metformin 500mg", "Merck & Co.", "Antidiabetic", "MET-7721",
             (today + timedelta(days=320)).isoformat(), 14.00, 120, 20),

            ("Omeprazole 20mg", "AstraZeneca", "Gastrointestinal", "OMP-5510",
             (today + timedelta(days=280)).isoformat(), 18.50, 95, 15),

            ("Atorvastatin 10mg", "Pfizer Inc.", "Cardiovascular", "ATV-8834",
             (today + timedelta(days=365)).isoformat(), 25.00, 80, 15),

            ("Pantoprazole 40mg", "Sun Pharma", "Gastrointestinal", "PAN-2219",
             (today + timedelta(days=190)).isoformat(), 16.00, 110, 20),

            ("Vitamin C 500mg Chewable", "Bayer Healthcare", "Supplements", "VTC-3388",
             (today + timedelta(days=400)).isoformat(), 7.50, 140, 25),

            ("Dolo 650mg", "Micro Labs", "Antipyretic", "DOL-5544",
             (today + timedelta(days=240)).isoformat(), 4.50, 180, 30)
        ]

        cursor.executemany("""
        INSERT INTO medicines 
        (medicine_name, company, category, batch_no, expiry_date, price, quantity, reorder_level)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, medicines_data)

    # Check if purchases exist
    cursor.execute("SELECT COUNT(*) as count FROM purchases")
    if cursor.fetchone()['count'] == 0:
        today = date.today()
        # 5 sample purchases
        purchases_data = [
            (1, 1, 50, 10.50, (today - timedelta(days=25)).isoformat()),
            (7, 2, 100, 9.00, (today - timedelta(days=18)).isoformat()),
            (8, 1, 80, 13.00, (today - timedelta(days=12)).isoformat()),
            (9, 3, 60, 18.00, (today - timedelta(days=8)).isoformat()),
            (11, 2, 120, 4.50, (today - timedelta(days=3)).isoformat()),
        ]
        cursor.executemany("""
        INSERT INTO purchases (medicine_id, supplier_id, quantity, purchase_price, purchase_date)
        VALUES (?, ?, ?, ?, ?)
        """, purchases_data)

    # Check if sales exist
    cursor.execute("SELECT COUNT(*) as count FROM sales")
    if cursor.fetchone()['count'] == 0:
        today = date.today()
        # 12 sample sales distributed across the past 7 days to fuel the Chart.js visual
        # Fields: (medicine_id, customer_name, quantity, selling_price, total_amount, sale_date)
        sales_data = [
            (7, "John Davis", 2, 14.00, 28.00, (today - timedelta(days=6)).isoformat()),
            (8, "Emma Watson", 1, 18.50, 18.50, (today - timedelta(days=6)).isoformat()),
            (9, "Robert Miller", 2, 25.00, 50.00, (today - timedelta(days=5)).isoformat()),
            (10, "Sophia Brown", 3, 16.00, 48.00, (today - timedelta(days=4)).isoformat()),
            (11, "Michael Johnson", 4, 7.50, 30.00, (today - timedelta(days=4)).isoformat()),
            (12, "Alice Green", 5, 4.50, 22.50, (today - timedelta(days=3)).isoformat()),
            (7, "David Clark", 3, 14.00, 42.00, (today - timedelta(days=2)).isoformat()),
            (8, "Olivia Taylor", 2, 18.50, 37.00, (today - timedelta(days=2)).isoformat()),
            (10, "Daniel White", 2, 16.00, 32.00, (today - timedelta(days=1)).isoformat()),
            (11, "Sarah Lee", 6, 7.50, 45.00, (today - timedelta(days=1)).isoformat()),
            (9, "William Harris", 1, 25.00, 25.00, today.isoformat()),
            (12, "Emily Martinez", 4, 4.50, 18.00, today.isoformat()),
        ]
        cursor.executemany("""
        INSERT INTO sales (medicine_id, customer_name, quantity, selling_price, total_amount, sale_date)
        VALUES (?, ?, ?, ?, ?, ?)
        """, sales_data)

    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print("Database initialized successfully at:", DB_PATH)
