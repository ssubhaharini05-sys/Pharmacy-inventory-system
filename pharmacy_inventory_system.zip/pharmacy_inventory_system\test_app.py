"""
Comprehensive Automated Test Suite for Pharmacy Inventory Management System.
Tests all endpoints, security access controls, business logic (stock adjustments, billing, reports, CSV exports).
"""

import unittest
import os
import sqlite3
from app import app
import database


class PharmacyInventorySystemTestCase(unittest.TestCase):
    def setUp(self):
        # Configure app for testing
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()

    def test_01_database_tables_and_seed_data(self):
        """Verify SQLite database exists and has all required tables and sample data."""
        conn = database.get_db_connection()
        cursor = conn.cursor()

        # Check tables exist
        tables = ["users", "medicines", "suppliers", "purchases", "sales"]
        for table in tables:
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
            self.assertIsNotNone(cursor.fetchone(), f"Table {table} must exist")

        # Check sample data
        cursor.execute("SELECT COUNT(*) as count FROM users")
        self.assertGreaterEqual(cursor.fetchone()['count'], 2, "Should have admin and staff users")

        cursor.execute("SELECT COUNT(*) as count FROM suppliers")
        self.assertGreaterEqual(cursor.fetchone()['count'], 3, "Should have at least 3 suppliers")

        cursor.execute("SELECT COUNT(*) as count FROM medicines")
        self.assertGreaterEqual(cursor.fetchone()['count'], 8, "Should have at least 8 medicines")

        cursor.execute("SELECT COUNT(*) as count FROM purchases")
        self.assertGreaterEqual(cursor.fetchone()['count'], 5, "Should have at least 5 purchases")

        cursor.execute("SELECT COUNT(*) as count FROM sales")
        self.assertGreaterEqual(cursor.fetchone()['count'], 10, "Should have at least 10 sales")

        # Verify low-stock count
        cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE quantity <= reorder_level")
        self.assertGreaterEqual(cursor.fetchone()['count'], 2, "Should have at least 2 low-stock medicines")

        # Verify expired count
        cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE expiry_date < date('now')")
        self.assertGreaterEqual(cursor.fetchone()['count'], 2, "Should have at least 2 expired medicines")

        # Verify expiring soon count (within 30 days)
        cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE expiry_date >= date('now') AND expiry_date <= date('now', '+30 days')")
        self.assertGreaterEqual(cursor.fetchone()['count'], 2, "Should have at least 2 medicines expiring in 30 days")

        conn.close()
        print(" [PASS] test_01_database_tables_and_seed_data")

    def test_02_authentication_and_route_protection(self):
        """Verify protected routes redirect unauthenticated users to login."""
        protected_routes = ["/dashboard", "/medicines", "/purchase", "/sell", "/suppliers", "/alerts", "/reports", "/users"]
        for route in protected_routes:
            res = self.client.get(route, follow_redirects=False)
            self.assertEqual(res.status_code, 302, f"Route {route} should redirect when unauthenticated")
            self.assertIn("/login", res.headers.get("Location"))

        # Test login with invalid credentials
        bad_login = self.client.post("/login", data={"username": "admin", "password": "wrongpassword"}, follow_redirects=True)
        self.assertIn(b"Invalid username or password", bad_login.data)

        # Test login with valid admin credentials
        good_login = self.client.post("/login", data={"username": "admin", "password": "admin123"}, follow_redirects=True)
        self.assertEqual(good_login.status_code, 200)
        self.assertIn(b"Pharma", good_login.data)
        self.assertIn(b"Pharmacy Dashboard", good_login.data)
        print(" [PASS] test_02_authentication_and_route_protection")

    def test_03_dashboard_and_chart(self):
        """Verify dashboard displays key stats and Chart.js configuration."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        res = self.client.get("/dashboard")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Pharmacy Dashboard", res.data)
        self.assertIn(b"salesChart", res.data)
        self.assertIn(b"Stock In Hand", res.data)
        print(" [PASS] test_03_dashboard_and_chart")

    def test_04_medicine_crud(self):
        """Verify adding, searching, editing, and deleting medicines."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        # 1. Add new medicine
        add_res = self.client.post("/medicines/add", data={
            "medicine_name": "Test Antibiotic 500mg",
            "company": "Test Pharma Ltd",
            "category": "Antibiotics",
            "batch_no": "TEST-1234",
            "expiry_date": "2027-12-31",
            "price": "19.99",
            "quantity": "50",
            "reorder_level": "10"
        }, follow_redirects=True)
        self.assertEqual(add_res.status_code, 200)
        self.assertIn(b"Test Antibiotic 500mg", add_res.data)

        # 2. Search medicine
        search_res = self.client.get("/medicines?search=Test+Antibiotic")
        self.assertIn(b"TEST-1234", search_res.data)

        # 3. Edit medicine
        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM medicines WHERE batch_no = 'TEST-1234'")
        med_id = cursor.fetchone()["id"]
        conn.close()

        edit_res = self.client.post(f"/medicines/edit/{med_id}", data={
            "medicine_name": "Test Antibiotic 500mg (Updated)",
            "company": "Test Pharma Ltd",
            "category": "Antibiotics",
            "batch_no": "TEST-1234",
            "expiry_date": "2027-12-31",
            "price": "24.99",
            "quantity": "65",
            "reorder_level": "15"
        }, follow_redirects=True)
        self.assertEqual(edit_res.status_code, 200)
        self.assertIn(b"Test Antibiotic 500mg (Updated)", edit_res.data)

        # 4. Delete medicine
        del_res = self.client.post(f"/medicines/delete/{med_id}", follow_redirects=True)
        self.assertEqual(del_res.status_code, 200)
        self.assertIn(b"deleted successfully", del_res.data)
        print(" [PASS] test_04_medicine_crud")

    def test_05_purchase_restocking_increases_inventory(self):
        """Verify that adding a purchase automatically increases medicine stock."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        conn = database.get_db_connection()
        cursor = conn.cursor()
        # Pick a well-stocked medicine so we don't disturb the low-stock sample count
        cursor.execute("SELECT id, quantity FROM medicines WHERE quantity > 50 ORDER BY id ASC LIMIT 1")
        med = cursor.fetchone()
        med_id = med["id"]
        initial_qty = med["quantity"]
        conn.close()

        purchase_qty = 25
        res = self.client.post("/purchase", data={
            "medicine_id": med_id,
            "supplier_id": 1,
            "quantity": purchase_qty,
            "purchase_price": "8.50",
            "purchase_date": "2026-11-20"
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Check stock increased
        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT quantity FROM medicines WHERE id = ?", (med_id,))
        updated_qty = cursor.fetchone()["quantity"]
        self.assertEqual(updated_qty, initial_qty + purchase_qty, "Medicine stock should be incremented by purchase qty")

        # Clean up test purchase and restore quantity
        cursor.execute("UPDATE medicines SET quantity = ? WHERE id = ?", (initial_qty, med_id))
        cursor.execute("DELETE FROM purchases WHERE id = (SELECT MAX(id) FROM purchases)")
        conn.commit()
        conn.close()

        print(" [PASS] test_05_purchase_restocking_increases_inventory")

    def test_06_sales_billing_and_stock_check(self):
        """Verify sales stock check, automatic deduction, and printable invoice generation."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, quantity, price FROM medicines WHERE quantity > 50 LIMIT 1")
        med = cursor.fetchone()
        med_id = med["id"]
        initial_qty = med["quantity"]
        conn.close()

        # 1. Attempt sale exceeding stock -> Must fail with Insufficient stock
        excess_res = self.client.post("/sell", data={
            "medicine_id": med_id,
            "customer_name": "Test Customer",
            "quantity": initial_qty + 500,
            "sale_date": "2026-11-20"
        }, follow_redirects=True)
        self.assertIn(b"Insufficient stock", excess_res.data)

        # 2. Valid sale within available stock -> Must deduct stock and generate invoice
        sell_qty = 2
        valid_res = self.client.post("/sell", data={
            "medicine_id": med_id,
            "customer_name": "Jane Doe",
            "quantity": sell_qty,
            "sale_date": "2026-11-20"
        }, follow_redirects=True)
        self.assertEqual(valid_res.status_code, 200)
        self.assertIn(b"RETAIL INVOICE", valid_res.data)
        self.assertIn(b"Jane Doe", valid_res.data)

        # Verify stock decreased
        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT quantity FROM medicines WHERE id = ?", (med_id,))
        new_qty = cursor.fetchone()["quantity"]
        self.assertEqual(new_qty, initial_qty - sell_qty, "Medicine stock must be reduced by sold quantity")

        # Clean up test sale and restore quantity
        cursor.execute("UPDATE medicines SET quantity = ? WHERE id = ?", (initial_qty, med_id))
        cursor.execute("DELETE FROM sales WHERE id = (SELECT MAX(id) FROM sales)")
        conn.commit()
        conn.close()

        print(" [PASS] test_06_sales_billing_and_stock_check")

    def test_07_supplier_management(self):
        """Verify supplier directory and CRUD."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        # Add supplier
        add_sup = self.client.post("/suppliers/add", data={
            "supplier_name": "Global Pharma Trade",
            "phone": "+1 555-0987",
            "email": "procurement@globalpharma.com",
            "address": "900 Trade Center Blvd"
        }, follow_redirects=True)
        self.assertEqual(add_sup.status_code, 200)
        self.assertIn(b"Global Pharma Trade", add_sup.data)

        # Fetch ID
        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM suppliers WHERE supplier_name = 'Global Pharma Trade'")
        sup_id = cursor.fetchone()["id"]
        conn.close()

        # Edit supplier
        edit_sup = self.client.post(f"/suppliers/edit/{sup_id}", data={
            "supplier_name": "Global Pharma Trade Inc.",
            "phone": "+1 555-0988",
            "email": "procurement@globalpharma.com",
            "address": "900 Trade Center Blvd, Suite 400"
        }, follow_redirects=True)
        self.assertEqual(edit_sup.status_code, 200)
        self.assertIn(b"Global Pharma Trade Inc.", edit_sup.data)

        # Delete supplier
        del_sup = self.client.post(f"/suppliers/delete/{sup_id}", follow_redirects=True)
        self.assertEqual(del_sup.status_code, 200)
        self.assertIn(b"deleted successfully", del_sup.data)
        print(" [PASS] test_07_supplier_management")

    def test_08_alerts_page(self):
        """Verify alerts interface lists low stock, expiring soon, and expired medicines."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        res = self.client.get("/alerts")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Expired Medicines", res.data)
        self.assertIn(b"Medicines Expiring Within 30 Days", res.data)
        self.assertIn(b"Low-Stock Medicines", res.data)
        print(" [PASS] test_08_alerts_page")

    def test_09_reports_and_csv_downloads(self):
        """Verify reports interface and that all 4 CSV download endpoints return valid CSV files."""
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        # Reports page
        res = self.client.get("/reports")
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Current Stock Valuation Report", res.data)
        self.assertIn(b"Date-Wise Sales Summary", res.data)

        # CSV 1: Stock CSV
        stock_csv = self.client.get("/reports/stock/csv")
        self.assertEqual(stock_csv.status_code, 200)
        self.assertIn("text/csv", stock_csv.content_type)
        self.assertIn(b"Medicine Name,Company,Category", stock_csv.data)

        # CSV 2: Sales CSV
        sales_csv = self.client.get("/reports/sales/csv")
        self.assertEqual(sales_csv.status_code, 200)
        self.assertIn("text/csv", sales_csv.content_type)
        self.assertIn(b"Bill ID,Sale Date,Customer Name", sales_csv.data)

        # CSV 3: Purchases CSV
        purch_csv = self.client.get("/reports/purchases/csv")
        self.assertEqual(purch_csv.status_code, 200)
        self.assertIn("text/csv", purch_csv.content_type)
        self.assertIn(b"Purchase ID,Purchase Date,Medicine Name", purch_csv.data)

        # CSV 4: Expiry CSV
        expiry_csv = self.client.get("/reports/expiry/csv")
        self.assertEqual(expiry_csv.status_code, 200)
        self.assertIn("text/csv", expiry_csv.content_type)
        self.assertIn(b"ID,Medicine Name,Company", expiry_csv.data)
        print(" [PASS] test_09_reports_and_csv_downloads")

    def test_10_role_based_access_and_user_management(self):
        """Verify staff cannot access /users, and admin can manage users without self-deletion."""
        # 1. Test as Staff
        with self.client.session_transaction() as sess:
            sess["user_id"] = 2
            sess["username"] = "staff"
            sess["role"] = "staff"

        staff_blocked = self.client.get("/users", follow_redirects=True)
        self.assertEqual(staff_blocked.status_code, 200)
        self.assertIn(b"Access denied: Administrator privileges required", staff_blocked.data)

        # 2. Test as Admin
        with self.client.session_transaction() as sess:
            sess["user_id"] = 1
            sess["username"] = "admin"
            sess["role"] = "admin"

        admin_allowed = self.client.get("/users")
        self.assertEqual(admin_allowed.status_code, 200)
        self.assertIn(b"System User Management", admin_allowed.data)

        # Admin adds a new user
        add_u = self.client.post("/users/add", data={
            "username": "new_staff_member",
            "password": "securepass123",
            "role": "staff"
        }, follow_redirects=True)
        self.assertEqual(add_u.status_code, 200)
        self.assertIn(b"created successfully", add_u.data)

        # Admin tries to delete own account -> Must be rejected
        del_self = self.client.post("/users/delete/1", follow_redirects=True)
        self.assertIn(b"You cannot delete your own logged-in admin account", del_self.data)

        # Admin deletes the new staff member
        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE username = 'new_staff_member'")
        new_u_id = cursor.fetchone()["id"]
        conn.close()

        del_other = self.client.post(f"/users/delete/{new_u_id}", follow_redirects=True)
        self.assertIn(b"deleted successfully", del_other.data)
        print(" [PASS] test_10_role_based_access_and_user_management")


if __name__ == "__main__":
    unittest.main()
