"""
Pharmacy Inventory Management System
Main Flask Application

Features:
- Authentication & Session Management (Admin and Staff roles)
- Dashboard with Metrics and Chart.js 7-Day Sales Visualization
- Medicine Inventory Management (CRUD, Stock Status, Search/Filter)
- Purchase Tracking & Automatic Stock Increase
- Sales / Billing with Automatic Stock Deduction & Printable Invoice
- Supplier Management
- Low-Stock and Expiry Date Alert System
- Comprehensive Reports with CSV Export
- Admin-Only User Management
"""

import os
import io
import csv
from datetime import date, timedelta
from functools import wraps
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, Response, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash
import database

# Initialize Flask application
app = Flask(__name__)
app.secret_key = "pharmacy_inventory_secret_key_college_project_2026"

# Ensure SQLite database and sample data are created on application start
database.init_db()


# ---------------------------------------------------------
# AUTHENTICATION HELPERS & DECORATORS
# ---------------------------------------------------------
def login_required(f):
    """
    Decorator to restrict access to authenticated users only.
    Redirects unauthenticated visitors to the login page.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """
    Decorator to restrict access to admin users only.
    Prevents staff accounts from accessing user management.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            flash("Access denied: Administrator privileges required.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated_function


@app.context_processor
def inject_global_data():
    """
    Inject global variables into all Jinja2 templates,
    such as current date and alert counts for the navbar badge.
    """
    today_str = date.today().isoformat()
    conn = database.get_db_connection()
    cursor = conn.cursor()

    # Low stock count
    cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE quantity <= reorder_level")
    low_stock_count = cursor.fetchone()["count"]

    # Expiring within 30 days
    in_30_days = (date.today() + timedelta(days=30)).isoformat()
    cursor.execute("""
        SELECT COUNT(*) as count FROM medicines 
        WHERE expiry_date >= ? AND expiry_date <= ?
    """, (today_str, in_30_days))
    expiring_soon_count = cursor.fetchone()["count"]

    # Expired count
    cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE expiry_date < ?", (today_str,))
    expired_count = cursor.fetchone()["count"]

    total_alerts = low_stock_count + expiring_soon_count + expired_count
    conn.close()

    return {
        "current_user": session.get("username"),
        "user_role": session.get("role"),
        "total_alerts_count": total_alerts,
        "today_date": today_str
    }


# ---------------------------------------------------------
# AUTHENTICATION ROUTES
# ---------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    """
    User login route. Authenticates against users table with password hash.
    """
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            flash(f"Welcome back, {user['username']}! Logged in as {user['role'].capitalize()}.", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password. Please try again.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    """
    Clear session and log out the user.
    """
    session.clear()
    flash("You have been successfully logged out.", "info")
    return redirect(url_for("login"))


# ---------------------------------------------------------
# DASHBOARD
# ---------------------------------------------------------
@app.route("/")
@app.route("/dashboard")
@login_required
def dashboard():
    """
    Main dashboard displaying key inventory metrics,
    7-day sales Chart.js graph, and critical alerts.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    today_str = date.today().isoformat()
    in_30_days = (date.today() + timedelta(days=30)).isoformat()

    # 1. Total Medicines
    cursor.execute("SELECT COUNT(*) as count FROM medicines")
    total_medicines = cursor.fetchone()["count"]

    # 2. Total Stock Units
    cursor.execute("SELECT IFNULL(SUM(quantity), 0) as total_qty FROM medicines")
    total_stock_qty = cursor.fetchone()["total_qty"]

    # 3. Low stock count
    cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE quantity <= reorder_level")
    low_stock_count = cursor.fetchone()["count"]

    # 4. Expiring within 30 days
    cursor.execute("""
        SELECT COUNT(*) as count FROM medicines 
        WHERE expiry_date >= ? AND expiry_date <= ?
    """, (today_str, in_30_days))
    expiring_soon_count = cursor.fetchone()["count"]

    # 5. Expired count
    cursor.execute("SELECT COUNT(*) as count FROM medicines WHERE expiry_date < ?", (today_str,))
    expired_count = cursor.fetchone()["count"]

    # 6. Today's sales amount
    cursor.execute("SELECT IFNULL(SUM(total_amount), 0) as today_sales FROM sales WHERE date(sale_date) = ?", (today_str,))
    today_sales = cursor.fetchone()["today_sales"]

    # 7. Total all-time sales
    cursor.execute("SELECT IFNULL(SUM(total_amount), 0) as total_sales FROM sales")
    all_time_sales = cursor.fetchone()["total_sales"]

    # 8. Sales in the last 7 days for Chart.js
    chart_labels = []
    chart_data = []
    for i in range(6, -1, -1):
        target_day = date.today() - timedelta(days=i)
        target_str = target_day.isoformat()
        cursor.execute("SELECT IFNULL(SUM(total_amount), 0) as day_total FROM sales WHERE date(sale_date) = ?", (target_str,))
        amt = cursor.fetchone()["day_total"]
        chart_labels.append(target_day.strftime("%b %d"))
        chart_data.append(round(amt, 2))

    # 9. Recent low-stock preview (up to 5)
    cursor.execute("""
        SELECT id, medicine_name, company, quantity, reorder_level 
        FROM medicines 
        WHERE quantity <= reorder_level 
        ORDER BY quantity ASC LIMIT 5
    """)
    recent_low_stock = cursor.fetchall()

    # 10. Recent expiring/expired preview (up to 5)
    cursor.execute("""
        SELECT id, medicine_name, company, expiry_date, quantity 
        FROM medicines 
        WHERE expiry_date <= ? 
        ORDER BY expiry_date ASC LIMIT 5
    """, (in_30_days,))
    recent_expiring = cursor.fetchall()

    conn.close()

    return render_template(
        "dashboard.html",
        total_medicines=total_medicines,
        total_stock_qty=total_stock_qty,
        low_stock_count=low_stock_count,
        expiring_soon_count=expiring_soon_count,
        expired_count=expired_count,
        today_sales=today_sales,
        all_time_sales=all_time_sales,
        chart_labels=chart_labels,
        chart_data=chart_data,
        recent_low_stock=recent_low_stock,
        recent_expiring=recent_expiring
    )


# ---------------------------------------------------------
# MEDICINE MANAGEMENT
# ---------------------------------------------------------
@app.route("/medicines")
@login_required
def medicines():
    """
    Display all medicines in a searchable and filterable table.
    """
    search_query = request.args.get("search", "").strip()
    category_filter = request.args.get("category", "").strip()

    conn = database.get_db_connection()
    cursor = conn.cursor()

    # Fetch unique categories for dropdown filter
    cursor.execute("SELECT DISTINCT category FROM medicines ORDER BY category ASC")
    categories = [row["category"] for row in cursor.fetchall()]

    query = "SELECT * FROM medicines WHERE 1=1"
    params = []

    if search_query:
        query += " AND (medicine_name LIKE ? OR company LIKE ? OR category LIKE ? OR batch_no LIKE ?)"
        like_term = f"%{search_query}%"
        params.extend([like_term, like_term, like_term, like_term])

    if category_filter:
        query += " AND category = ?"
        params.append(category_filter)

    query += " ORDER BY medicine_name ASC"
    cursor.execute(query, params)
    medicine_list = cursor.fetchall()
    conn.close()

    today_str = date.today().isoformat()
    in_30_days = (date.today() + timedelta(days=30)).isoformat()

    return render_template(
        "medicines.html",
        medicines=medicine_list,
        categories=categories,
        search_query=search_query,
        category_filter=category_filter,
        today_str=today_str,
        in_30_days=in_30_days
    )


@app.route("/medicines/add", methods=["GET", "POST"])
@login_required
def add_medicine():
    """
    Add a new medicine record to inventory.
    """
    if request.method == "POST":
        medicine_name = request.form.get("medicine_name", "").strip()
        company = request.form.get("company", "").strip()
        category = request.form.get("category", "").strip()
        batch_no = request.form.get("batch_no", "").strip()
        expiry_date = request.form.get("expiry_date", "").strip()
        price = request.form.get("price", "0")
        quantity = request.form.get("quantity", "0")
        reorder_level = request.form.get("reorder_level", "10")

        # Validation
        if not medicine_name or not company or not category or not batch_no or not expiry_date:
            flash("All fields marked with an asterisk are required.", "danger")
            return render_template("add_medicine.html")

        try:
            price_val = float(price)
            qty_val = int(quantity)
            reorder_val = int(reorder_level)
            if price_val < 0 or qty_val < 0 or reorder_val < 0:
                raise ValueError("Values cannot be negative.")
        except ValueError:
            flash("Please enter valid numeric values for price, quantity, and reorder level.", "danger")
            return render_template("add_medicine.html")

        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO medicines 
            (medicine_name, company, category, batch_no, expiry_date, price, quantity, reorder_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (medicine_name, company, category, batch_no, expiry_date, price_val, qty_val, reorder_val))
        conn.commit()
        conn.close()

        flash(f"Medicine '{medicine_name}' added successfully!", "success")
        return redirect(url_for("medicines"))

    return render_template("add_medicine.html")


@app.route("/medicines/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit_medicine(id):
    """
    Edit details of an existing medicine.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM medicines WHERE id = ?", (id,))
    med = cursor.fetchone()

    if not med:
        conn.close()
        flash("Medicine not found.", "warning")
        return redirect(url_for("medicines"))

    if request.method == "POST":
        medicine_name = request.form.get("medicine_name", "").strip()
        company = request.form.get("company", "").strip()
        category = request.form.get("category", "").strip()
        batch_no = request.form.get("batch_no", "").strip()
        expiry_date = request.form.get("expiry_date", "").strip()
        price = request.form.get("price", "0")
        quantity = request.form.get("quantity", "0")
        reorder_level = request.form.get("reorder_level", "10")

        try:
            price_val = float(price)
            qty_val = int(quantity)
            reorder_val = int(reorder_level)
            if price_val < 0 or qty_val < 0 or reorder_val < 0:
                raise ValueError("Values cannot be negative.")
        except ValueError:
            flash("Please enter valid positive numbers.", "danger")
            conn.close()
            return render_template("edit_medicine.html", medicine=med)

        cursor.execute("""
            UPDATE medicines 
            SET medicine_name = ?, company = ?, category = ?, batch_no = ?, 
                expiry_date = ?, price = ?, quantity = ?, reorder_level = ?
            WHERE id = ?
        """, (medicine_name, company, category, batch_no, expiry_date, price_val, qty_val, reorder_val, id))
        conn.commit()
        conn.close()

        flash(f"Medicine '{medicine_name}' updated successfully!", "success")
        return redirect(url_for("medicines"))

    conn.close()
    return render_template("edit_medicine.html", medicine=med)


@app.route("/medicines/delete/<int:id>", methods=["POST"])
@login_required
def delete_medicine(id):
    """
    Delete a medicine from inventory.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT medicine_name FROM medicines WHERE id = ?", (id,))
    med = cursor.fetchone()
    if med:
        cursor.execute("DELETE FROM medicines WHERE id = ?", (id,))
        conn.commit()
        flash(f"Medicine '{med['medicine_name']}' deleted successfully.", "info")
    else:
        flash("Medicine record not found.", "warning")
    conn.close()
    return redirect(url_for("medicines"))


# ---------------------------------------------------------
# PURCHASE MANAGEMENT (Automatic Stock Increase)
# ---------------------------------------------------------
@app.route("/purchase", methods=["GET", "POST"])
@login_required
def purchase():
    """
    Record a medicine purchase from a supplier.
    Automatically increments the stock quantity of the selected medicine.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        medicine_id = request.form.get("medicine_id")
        supplier_id = request.form.get("supplier_id")
        quantity = request.form.get("quantity")
        purchase_price = request.form.get("purchase_price")
        purchase_date = request.form.get("purchase_date", date.today().isoformat())

        try:
            med_id = int(medicine_id)
            sup_id = int(supplier_id)
            qty = int(quantity)
            price = float(purchase_price)
            if qty <= 0 or price < 0:
                raise ValueError("Quantity must be greater than zero and price cannot be negative.")
        except (ValueError, TypeError):
            flash("Please enter valid numbers for quantity and purchase price.", "danger")
            conn.close()
            return redirect(url_for("purchase"))

        # Verify medicine and supplier exist
        cursor.execute("SELECT medicine_name, quantity FROM medicines WHERE id = ?", (med_id,))
        med = cursor.fetchone()
        cursor.execute("SELECT supplier_name FROM suppliers WHERE id = ?", (sup_id,))
        sup = cursor.fetchone()

        if not med or not sup:
            flash("Selected medicine or supplier does not exist.", "danger")
            conn.close()
            return redirect(url_for("purchase"))

        # 1. Insert into purchases table
        cursor.execute("""
            INSERT INTO purchases (medicine_id, supplier_id, quantity, purchase_price, purchase_date)
            VALUES (?, ?, ?, ?, ?)
        """, (med_id, sup_id, qty, price, purchase_date))

        # 2. Automatically increase the medicine stock quantity
        new_qty = med["quantity"] + qty
        cursor.execute("UPDATE medicines SET quantity = ? WHERE id = ?", (new_qty, med_id))

        conn.commit()
        flash(
            f"Purchase recorded! Added {qty} units of '{med['medicine_name']}'. "
            f"New stock: {new_qty} units.",
            "success"
        )
        conn.close()
        return redirect(url_for("purchase"))

    # GET request: load medicines, suppliers, and purchase history
    preselect_med_id = request.args.get("medicine_id", type=int)

    cursor.execute("SELECT id, medicine_name, company, quantity, price FROM medicines ORDER BY medicine_name ASC")
    medicines_list = cursor.fetchall()

    cursor.execute("SELECT id, supplier_name FROM suppliers ORDER BY supplier_name ASC")
    suppliers_list = cursor.fetchall()

    cursor.execute("""
        SELECT p.id, p.quantity, p.purchase_price, (p.quantity * p.purchase_price) as total_cost,
               p.purchase_date, p.created_at,
               m.medicine_name, m.company, s.supplier_name
        FROM purchases p
        JOIN medicines m ON p.medicine_id = m.id
        JOIN suppliers s ON p.supplier_id = s.id
        ORDER BY p.id DESC
    """)
    purchase_history = cursor.fetchall()
    conn.close()

    return render_template(
        "purchase.html",
        medicines=medicines_list,
        suppliers=suppliers_list,
        purchases=purchase_history,
        preselect_med_id=preselect_med_id,
        today_date=date.today().isoformat()
    )


# ---------------------------------------------------------
# SALES / BILLING MANAGEMENT (Automatic Stock Deduction)
# ---------------------------------------------------------
@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """
    Record a medicine sale to a customer.
    Checks available stock:
    - If insufficient: returns "Insufficient stock" error.
    - If sufficient: automatically decreases stock and generates a bill summary.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        medicine_id = request.form.get("medicine_id")
        customer_name = request.form.get("customer_name", "Walk-in Customer").strip()
        quantity_str = request.form.get("quantity")
        sale_date = request.form.get("sale_date", date.today().isoformat())

        if not customer_name:
            customer_name = "Walk-in Customer"

        try:
            med_id = int(medicine_id)
            req_qty = int(quantity_str)
            if req_qty <= 0:
                raise ValueError("Quantity must be greater than zero.")
        except (ValueError, TypeError):
            flash("Please specify a valid quantity greater than zero.", "danger")
            conn.close()
            return redirect(url_for("sell"))

        # Fetch medicine details
        cursor.execute("SELECT * FROM medicines WHERE id = ?", (med_id,))
        med = cursor.fetchone()

        if not med:
            flash("Selected medicine not found.", "danger")
            conn.close()
            return redirect(url_for("sell"))

        # STOCK CHECK: Verify available inventory
        if med["quantity"] < req_qty:
            flash(
                f"Insufficient stock! Only {med['quantity']} units of '{med['medicine_name']}' available.",
                "danger"
            )
            conn.close()
            return redirect(url_for("sell"))

        # Calculate billing
        unit_price = med["price"]
        total_amount = round(req_qty * unit_price, 2)

        # 1. Deduct stock quantity
        new_qty = med["quantity"] - req_qty
        cursor.execute("UPDATE medicines SET quantity = ? WHERE id = ?", (new_qty, med_id))

        # 2. Insert sale record
        cursor.execute("""
            INSERT INTO sales (medicine_id, customer_name, quantity, selling_price, total_amount, sale_date)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (med_id, customer_name, req_qty, unit_price, total_amount, sale_date))

        sale_id = cursor.lastrowid
        conn.commit()
        conn.close()

        flash(f"Sale completed successfully! Invoice #{sale_id} generated.", "success")
        return redirect(url_for("view_bill", sale_id=sale_id))

    # GET request: load medicines and sales history
    preselect_med_id = request.args.get("medicine_id", type=int)

    cursor.execute("SELECT id, medicine_name, company, price, quantity FROM medicines ORDER BY medicine_name ASC")
    medicines_list = cursor.fetchall()

    cursor.execute("""
        SELECT s.id, s.customer_name, s.quantity, s.selling_price, s.total_amount, s.sale_date,
               m.medicine_name, m.company
        FROM sales s
        JOIN medicines m ON s.medicine_id = m.id
        ORDER BY s.id DESC
    """)
    sales_history = cursor.fetchall()

    # Calculate today's sales total
    cursor.execute("SELECT IFNULL(SUM(total_amount), 0) as today_total FROM sales WHERE date(sale_date) = ?", (date.today().isoformat(),))
    today_total = cursor.fetchone()["today_total"]

    conn.close()

    return render_template(
        "sell.html",
        medicines=medicines_list,
        sales=sales_history,
        today_total=today_total,
        preselect_med_id=preselect_med_id,
        today_date=date.today().isoformat()
    )


@app.route("/bill/<int:sale_id>")
@login_required
def view_bill(sale_id):
    """
    Display a clean, printable bill / invoice receipt for a completed sale.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT s.id as invoice_no, s.customer_name, s.quantity, s.selling_price, 
               s.total_amount, s.sale_date, s.created_at,
               m.medicine_name, m.company, m.category, m.batch_no, m.expiry_date
        FROM sales s
        JOIN medicines m ON s.medicine_id = m.id
        WHERE s.id = ?
    """, (sale_id,))
    bill = cursor.fetchone()
    conn.close()

    if not bill:
        flash("Invoice not found.", "warning")
        return redirect(url_for("sell"))

    return render_template("bill.html", bill=bill)


# ---------------------------------------------------------
# SUPPLIER MANAGEMENT
# ---------------------------------------------------------
@app.route("/suppliers")
@login_required
def suppliers():
    """
    Display list of all medicine suppliers.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT s.*, 
               (SELECT COUNT(*) FROM purchases WHERE supplier_id = s.id) as total_purchases
        FROM suppliers s
        ORDER BY s.supplier_name ASC
    """)
    suppliers_list = cursor.fetchall()
    conn.close()
    return render_template("suppliers.html", suppliers=suppliers_list)


@app.route("/suppliers/add", methods=["GET", "POST"])
@login_required
def add_supplier():
    """
    Add a new supplier.
    """
    if request.method == "POST":
        supplier_name = request.form.get("supplier_name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        address = request.form.get("address", "").strip()

        if not supplier_name:
            flash("Supplier name is required.", "danger")
            return render_template("add_supplier.html")

        conn = database.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO suppliers (supplier_name, phone, email, address)
            VALUES (?, ?, ?, ?)
        """, (supplier_name, phone, email, address))
        conn.commit()
        conn.close()

        flash(f"Supplier '{supplier_name}' added successfully!", "success")
        return redirect(url_for("suppliers"))

    return render_template("add_supplier.html")


@app.route("/suppliers/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit_supplier(id):
    """
    Edit supplier details.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM suppliers WHERE id = ?", (id,))
    supplier = cursor.fetchone()

    if not supplier:
        conn.close()
        flash("Supplier not found.", "warning")
        return redirect(url_for("suppliers"))

    if request.method == "POST":
        supplier_name = request.form.get("supplier_name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        address = request.form.get("address", "").strip()

        if not supplier_name:
            flash("Supplier name cannot be empty.", "danger")
            conn.close()
            return render_template("edit_supplier.html", supplier=supplier)

        cursor.execute("""
            UPDATE suppliers 
            SET supplier_name = ?, phone = ?, email = ?, address = ?
            WHERE id = ?
        """, (supplier_name, phone, email, address, id))
        conn.commit()
        conn.close()

        flash(f"Supplier '{supplier_name}' updated successfully!", "success")
        return redirect(url_for("suppliers"))

    conn.close()
    return render_template("edit_supplier.html", supplier=supplier)


@app.route("/suppliers/delete/<int:id>", methods=["POST"])
@login_required
def delete_supplier(id):
    """
    Delete a supplier record.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT supplier_name FROM suppliers WHERE id = ?", (id,))
    sup = cursor.fetchone()
    if sup:
        cursor.execute("DELETE FROM suppliers WHERE id = ?", (id,))
        conn.commit()
        flash(f"Supplier '{sup['supplier_name']}' deleted successfully.", "info")
    else:
        flash("Supplier not found.", "warning")
    conn.close()
    return redirect(url_for("suppliers"))


# ---------------------------------------------------------
# EXPIRY & LOW STOCK ALERTS
# ---------------------------------------------------------
@app.route("/alerts")
@login_required
def alerts():
    """
    Display high-priority inventory alerts:
    - Low stock medicines (quantity <= reorder_level) highlighted in yellow/orange
    - Expiring soon medicines (within 30 days) highlighted in warning
    - Expired medicines (expiry_date < today) highlighted in RED
    """
    today_str = date.today().isoformat()
    in_30_days = (date.today() + timedelta(days=30)).isoformat()

    conn = database.get_db_connection()
    cursor = conn.cursor()

    # 1. Low Stock
    cursor.execute("""
        SELECT * FROM medicines 
        WHERE quantity <= reorder_level 
        ORDER BY quantity ASC
    """)
    low_stock_medicines = cursor.fetchall()

    # 2. Expiring within 30 days
    cursor.execute("""
        SELECT * FROM medicines 
        WHERE expiry_date >= ? AND expiry_date <= ? 
        ORDER BY expiry_date ASC
    """, (today_str, in_30_days))
    expiring_soon_medicines = cursor.fetchall()

    # 3. Already Expired
    cursor.execute("""
        SELECT * FROM medicines 
        WHERE expiry_date < ? 
        ORDER BY expiry_date ASC
    """, (today_str,))
    expired_medicines = cursor.fetchall()

    conn.close()

    return render_template(
        "alerts.html",
        low_stock_medicines=low_stock_medicines,
        expiring_soon_medicines=expiring_soon_medicines,
        expired_medicines=expired_medicines,
        today_str=today_str
    )


# ---------------------------------------------------------
# REPORTS & CSV EXPORT
# ---------------------------------------------------------
@app.route("/reports")
@login_required
def reports():
    """
    Comprehensive reporting interface displaying:
    - Stock Report
    - Sales Report
    - Purchase Report
    - Expiry Report
    """
    today_str = date.today().isoformat()
    in_30_days = (date.today() + timedelta(days=30)).isoformat()
    conn = database.get_db_connection()
    cursor = conn.cursor()

    # 1. Stock report data
    cursor.execute("""
        SELECT id, medicine_name, company, category, batch_no, quantity, price, 
               (quantity * price) as stock_value, reorder_level, expiry_date
        FROM medicines
        ORDER BY medicine_name ASC
    """)
    stock_report = cursor.fetchall()
    total_stock_value = sum(row["stock_value"] for row in stock_report)

    # 2. Sales summary by date
    cursor.execute("""
        SELECT sale_date, 
               COUNT(id) as total_bills, 
               SUM(quantity) as total_units, 
               SUM(total_amount) as total_revenue
        FROM sales
        GROUP BY sale_date
        ORDER BY sale_date DESC
    """)
    sales_report = cursor.fetchall()
    total_sales_revenue = sum(row["total_revenue"] for row in sales_report)

    # 3. Purchase report by supplier
    cursor.execute("""
        SELECT p.purchase_date, m.medicine_name, s.supplier_name, 
               p.quantity, p.purchase_price, (p.quantity * p.purchase_price) as total_cost
        FROM purchases p
        JOIN medicines m ON p.medicine_id = m.id
        JOIN suppliers s ON p.supplier_id = s.id
        ORDER BY p.purchase_date DESC
    """)
    purchase_report = cursor.fetchall()
    total_purchase_cost = sum(row["total_cost"] for row in purchase_report)

    # 4. Expiry report data
    cursor.execute("""
        SELECT id, medicine_name, company, batch_no, quantity, expiry_date
        FROM medicines
        ORDER BY expiry_date ASC
    """)
    expiry_report = cursor.fetchall()

    conn.close()

    return render_template(
        "reports.html",
        stock_report=stock_report,
        total_stock_value=total_stock_value,
        sales_report=sales_report,
        total_sales_revenue=total_sales_revenue,
        purchase_report=purchase_report,
        total_purchase_cost=total_purchase_cost,
        expiry_report=expiry_report,
        today_str=today_str,
        in_30_days=in_30_days
    )


@app.route("/reports/stock/csv")
@login_required
def export_stock_csv():
    """
    Download Stock Report as a CSV file.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, medicine_name, company, category, batch_no, quantity, price, 
               (quantity * price) as stock_value, reorder_level, expiry_date
        FROM medicines
        ORDER BY medicine_name ASC
    """)
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Medicine ID", "Medicine Name", "Company", "Category", 
        "Batch No", "Quantity in Stock", "Unit Selling Price ($)", 
        "Total Stock Value ($)", "Reorder Level", "Expiry Date", "Stock Status"
    ])

    for r in rows:
        status = "Available"
        if r["quantity"] == 0:
            status = "Out of Stock"
        elif r["quantity"] <= r["reorder_level"]:
            status = "Low Stock"

        writer.writerow([
            r["id"], r["medicine_name"], r["company"], r["category"],
            r["batch_no"], r["quantity"], f"{r['price']:.2f}",
            f"{r['stock_value']:.2f}", r["reorder_level"], r["expiry_date"], status
        ])

    csv_data = output.getvalue()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=pharmacy_stock_report.csv"}
    )


@app.route("/reports/sales/csv")
@login_required
def export_sales_csv():
    """
    Download Sales Report as a CSV file.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT s.id, s.sale_date, s.customer_name, m.medicine_name, 
               s.quantity, s.selling_price, s.total_amount
        FROM sales s
        JOIN medicines m ON s.medicine_id = m.id
        ORDER BY s.id DESC
    """)
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Bill ID", "Sale Date", "Customer Name", "Medicine Name", "Quantity Sold", "Unit Price ($)", "Total Amount ($)"])

    for r in rows:
        writer.writerow([
            r["id"], r["sale_date"], r["customer_name"], r["medicine_name"],
            r["quantity"], f"{r['selling_price']:.2f}", f"{r['total_amount']:.2f}"
        ])

    csv_data = output.getvalue()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=pharmacy_sales_report.csv"}
    )


@app.route("/reports/purchases/csv")
@login_required
def export_purchases_csv():
    """
    Download Purchase Report as a CSV file.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT p.id, p.purchase_date, m.medicine_name, s.supplier_name, 
               p.quantity, p.purchase_price, (p.quantity * p.purchase_price) as total_cost
        FROM purchases p
        JOIN medicines m ON p.medicine_id = m.id
        JOIN suppliers s ON p.supplier_id = s.id
        ORDER BY p.id DESC
    """)
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Purchase ID", "Purchase Date", "Medicine Name", "Supplier Name", "Quantity", "Purchase Price ($)", "Total Cost ($)"])

    for r in rows:
        writer.writerow([
            r["id"], r["purchase_date"], r["medicine_name"], r["supplier_name"],
            r["quantity"], f"{r['purchase_price']:.2f}", f"{r['total_cost']:.2f}"
        ])

    csv_data = output.getvalue()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=pharmacy_purchase_report.csv"}
    )


@app.route("/reports/expiry/csv")
@login_required
def export_expiry_csv():
    """
    Download Expiry Report as a CSV file.
    """
    today_str = date.today().isoformat()
    in_30_days = (date.today() + timedelta(days=30)).isoformat()

    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, medicine_name, company, batch_no, quantity, expiry_date
        FROM medicines
        ORDER BY expiry_date ASC
    """)
    rows = cursor.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Medicine Name", "Company", "Batch No", "Current Stock", "Expiry Date", "Status"])

    for r in rows:
        exp_date = r["expiry_date"]
        if exp_date < today_str:
            status = "EXPIRED"
        elif exp_date <= in_30_days:
            status = "Expiring Soon (< 30 Days)"
        else:
            status = "Valid / Safe"

        writer.writerow([r["id"], r["medicine_name"], r["company"], r["batch_no"], r["quantity"], exp_date, status])

    csv_data = output.getvalue()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=pharmacy_expiry_report.csv"}
    )


# ---------------------------------------------------------
# USER MANAGEMENT (Admin Only)
# ---------------------------------------------------------
@app.route("/users")
@admin_required
def users():
    """
    View all system users (Admin and Staff).
    Only accessible by Admin.
    """
    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, role, created_at FROM users ORDER BY id ASC")
    user_list = cursor.fetchall()
    conn.close()
    return render_template("users.html", users=user_list)


@app.route("/users/add", methods=["POST"])
@admin_required
def add_user():
    """
    Admin adds a new staff or admin user.
    """
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "staff").strip().lower()

    if not username or not password:
        flash("Username and password are required.", "danger")
        return redirect(url_for("users"))

    if role not in ["admin", "staff"]:
        role = "staff"

    conn = database.get_db_connection()
    cursor = conn.cursor()

    # Check for duplicate username
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        conn.close()
        flash(f"Username '{username}' already exists. Please choose a different username.", "warning")
        return redirect(url_for("users"))

    hashed_pw = generate_password_hash(password)
    cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", (username, hashed_pw, role))
    conn.commit()
    conn.close()

    flash(f"User '{username}' created successfully as {role.capitalize()}!", "success")
    return redirect(url_for("users"))


@app.route("/users/delete/<int:id>", methods=["POST"])
@admin_required
def delete_user(id):
    """
    Admin deletes a staff user. Admin cannot delete their own account.
    """
    if id == session.get("user_id"):
        flash("Action forbidden: You cannot delete your own logged-in admin account!", "danger")
        return redirect(url_for("users"))

    conn = database.get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT username, role FROM users WHERE id = ?", (id,))
    target_user = cursor.fetchone()

    if not target_user:
        conn.close()
        flash("User not found.", "warning")
        return redirect(url_for("users"))

    cursor.execute("DELETE FROM users WHERE id = ?", (id,))
    conn.commit()
    conn.close()

    flash(f"User '{target_user['username']}' deleted successfully.", "info")
    return redirect(url_for("users"))


# ---------------------------------------------------------
# APPLICATION ENTRY POINT
# ---------------------------------------------------------
if __name__ == "__main__":
    # Host on 127.0.0.1 port 5000 in debug mode
    print("=" * 60)
    print(" Pharmacy Inventory Management System")
    print(" Running at: http://127.0.0.1:5000")
    print(" Default Admin: admin / admin123")
    print(" Default Staff: staff / staff123")
    print("=" * 60)
    app.run(debug=True, port=5000)
