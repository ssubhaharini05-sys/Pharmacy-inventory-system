/**
 * Pharmacy Inventory Management System - Client Side JavaScript
 */

document.addEventListener("DOMContentLoaded", function () {
    // 1. Auto-calculate total in Sales / Billing page
    const medicineSelect = document.getElementById("sell_medicine_select");
    const sellQtyInput = document.getElementById("sell_quantity");
    const sellPriceDisplay = document.getElementById("sell_unit_price");
    const sellTotalDisplay = document.getElementById("sell_total_amount");
    const sellStockDisplay = document.getElementById("sell_available_stock");
    const stockWarning = document.getElementById("stock_warning");

    function updateSaleCalculations() {
        if (!medicineSelect) return;

        const selectedOption = medicineSelect.options[medicineSelect.selectedIndex];
        if (selectedOption && selectedOption.value) {
            const price = parseFloat(selectedOption.getAttribute("data-price")) || 0;
            const stock = parseInt(selectedOption.getAttribute("data-stock")) || 0;
            const qty = parseInt(sellQtyInput.value) || 0;

            if (sellPriceDisplay) sellPriceDisplay.textContent = "$" + price.toFixed(2);
            if (sellStockDisplay) sellStockDisplay.textContent = stock;

            const total = qty * price;
            if (sellTotalDisplay) sellTotalDisplay.textContent = "$" + total.toFixed(2);

            if (stockWarning) {
                if (qty > stock) {
                    stockWarning.classList.remove("d-none");
                    stockWarning.textContent = `Warning: Requested quantity (${qty}) exceeds available stock (${stock})!`;
                } else {
                    stockWarning.classList.add("d-none");
                }
            }
        } else {
            if (sellPriceDisplay) sellPriceDisplay.textContent = "$0.00";
            if (sellTotalDisplay) sellTotalDisplay.textContent = "$0.00";
            if (sellStockDisplay) sellStockDisplay.textContent = "0";
            if (stockWarning) stockWarning.classList.add("d-none");
        }
    }

    if (medicineSelect) {
        medicineSelect.addEventListener("change", updateSaleCalculations);
    }
    if (sellQtyInput) {
        sellQtyInput.addEventListener("input", updateSaleCalculations);
        updateSaleCalculations(); // Run on initial page load if preselected
    }

    // 2. Auto-calculate total in Purchase page
    const purchaseQty = document.getElementById("purchase_quantity");
    const purchasePrice = document.getElementById("purchase_price");
    const purchaseTotalDisplay = document.getElementById("purchase_total_cost");

    function updatePurchaseCalculations() {
        if (!purchaseQty || !purchasePrice) return;
        const qty = parseInt(purchaseQty.value) || 0;
        const price = parseFloat(purchasePrice.value) || 0;
        const total = qty * price;
        if (purchaseTotalDisplay) {
            purchaseTotalDisplay.textContent = "$" + total.toFixed(2);
        }
    }

    if (purchaseQty) purchaseQty.addEventListener("input", updatePurchaseCalculations);
    if (purchasePrice) purchasePrice.addEventListener("input", updatePurchaseCalculations);

    // 3. Auto-dismiss bootstrap alerts after 6 seconds
    const alerts = document.querySelectorAll(".alert-dismissible");
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 6000);
    });
});
