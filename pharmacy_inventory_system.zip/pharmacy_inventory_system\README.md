# Pharmacy Inventory Management System

A simple, complete, and ready-to-run web application built with **Python, Flask, and SQLite** to manage pharmaceutical medicine stocks, purchases, billing/sales, supplier contacts, automated low-stock and expiry alerts, reports with CSV export, and role-based user management.

Designed specifically for first-year college students and beginners: zero complex setup, no paid APIs or cloud dependencies, and automatic database creation on first run.

---

## 🚀 Key Features

1. **Automatic SQLite Database Initialization**:
   - The application automatically generates `pharmacy.db` and all required tables upon starting.
   - Automatically populates realistic sample data (medicines, suppliers, purchases, and sales across the past 7 days) so the dashboard and charts are immediately active.

2. **Role-Based User Authentication**:
   - **Admin**: Full access to all modules, including staff user creation and deletion.
   - **Staff**: Operational access to inventory, sales billing, purchase restocking, alerts, and reports.
   - Secure password hashing using Werkzeug.
   - Session-based access control protecting all routes from unauthenticated access.

3. **Interactive Visual Dashboard**:
   - Real-time statistics: Total Medicines, Stock in Hand, Low-Stock Count, Expiring Soon (<30 Days), Expired Medicines, Today's Sales, and All-Time Revenue.
   - Dynamic **Chart.js** 7-day sales bar chart.
   - Quick-action shortcuts for sales, restocking, and medicine creation.

4. **Medicine Inventory Management**:
   - Full CRUD: Add, View, Edit, and Delete medicines.
   - Search and filter by medicine name, company/manufacturer, category, or batch number.
   - Automatic visual status badges: **Available**, **Low Stock** (quantity &le; reorder level), or **Out of Stock** (quantity = 0).

5. **Purchase Management & Automatic Stock Increment**:
   - Record purchases with supplier, unit price, quantity, and date.
   - Automatically adds purchased quantities to the medicine's live inventory.

6. **Sales & Billing Counter (Automatic Stock Deduction)**:
   - Patient/customer billing counter.
   - Automatic real-time inventory verification: prevents selling more units than currently available with clear "Insufficient stock" feedback.
   - Automatically reduces medicine inventory upon successful sale.
   - Generates an instant, professional, printable **Retail Invoice / Receipt** with `window.print()` functionality.

7. **Expiry & Low-Stock Alert System**:
   - **Low Stock Medicines**: Highlighted in yellow/orange when stock is below reorder thresholds.
   - **Expiring Soon (< 30 Days)**: Highlighted in amber to enable timely dispensing.
   - **Expired Medicines**: Highlighted in **RED** with a prominent notice to quarantine and remove from shelves.

8. **Analytics & Reports (with CSV Download)**:
   - **Stock Valuation Report**: Itemized quantity and valuation with one-click CSV download.
   - **Date-Wise Sales Report**: Grouped sales volume and revenue with one-click CSV download.
   - **Procurement Report**: Detailed supplier purchase ledger with one-click CSV download.
   - **Expiry Audit Report**: Expiration log with one-click CSV download.

9. **User Management (Admin Only)**:
   - Admin can create new staff accounts and view registered users.
   - Admin can delete staff users; protection prevents an admin from deleting their own active account.

---

## 🛠️ Technology Stack

- **Backend**: Python 3, Flask
- **Database**: SQLite 3 (`pharmacy.db`) — zero configuration needed!
- **Frontend**: HTML5, CSS3, JavaScript (ES6)
- **UI Framework**: Bootstrap 5.3 & Bootstrap Icons
- **Data Visualization**: Chart.js 4
- **Templating**: Jinja2

---

## 🔑 Default Login Credentials

| Role | Username | Password | Access Level |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin` | `admin123` | Full access (including User Management) |
| **Staff** | `staff` | `staff123` | Inventory, Sales, Purchases, Alerts, Reports |

---

## 📁 Project Directory Structure

```text
pharmacy_inventory_system/
│
├── app.py                # Main Flask web application and routing logic
├── database.py           # SQLite database schema, initialization, and sample data
├── requirements.txt      # Python dependencies (Flask, Werkzeug)
├── README.md             # Complete documentation and setup guide
├── pharmacy.db           # SQLite database file (created automatically on first run)
│
├── templates/            # Jinja2 HTML templates
│   ├── base.html         # Master layout with responsive navbar, flash alerts, footer
│   ├── login.html        # Clean authentication card
│   ├── dashboard.html    # Key metrics, Chart.js sales graph, recent alerts
│   ├── medicines.html    # Searchable medicine inventory table
│   ├── add_medicine.html # Medicine registration form
│   ├── edit_medicine.html# Medicine edit form
│   ├── purchase.html     # Supplier restocking & purchase history
│   ├── sell.html         # Billing counter with live stock check
│   ├── bill.html         # Printable retail invoice / receipt
│   ├── suppliers.html    # Supplier directory table
│   ├── add_supplier.html # Supplier registration form
│   ├── edit_supplier.html# Supplier edit form
│   ├── alerts.html       # High-priority low stock & expiry alert boards
│   ├── reports.html      # Multi-tab reports (Stock, Sales, Purchases, Expiry)
│   └── users.html        # Admin user management portal
│
└── static/
    ├── css/
    │   └── style.css     # Clean medical theme styling and print media queries
    └── js/
        └── script.js     # Live price/stock calculations and UI interactions
```

---

## 🗄️ Database Tables Explanation

All tables are created in the SQLite file `pharmacy.db`:

1. **`users`**:
   - `id`: Unique primary key.
   - `username`: Login username (unique).
   - `password`: Hashed security password string.
   - `role`: Access level (`admin` or `staff`).
   - `created_at`: Account creation timestamp.

2. **`medicines`**:
   - `id`: Unique primary key.
   - `medicine_name`: Brand/chemical name of the drug.
   - `company`: Manufacturing pharmaceutical firm.
   - `category`: Therapeutic class (e.g., Antibiotics, Analgesics).
   - `batch_no`: Lot/batch number.
   - `expiry_date`: Expiration date (YYYY-MM-DD).
   - `price`: Unit retail selling price.
   - `quantity`: Current physical units in inventory.
   - `reorder_level`: Minimum threshold quantity triggering a low-stock alert.
   - `created_at`: Timestamp.

3. **`suppliers`**:
   - `id`: Unique primary key.
   - `supplier_name`: Distributor or vendor company name.
   - `phone`: Contact telephone.
   - `email`: Support or order email.
   - `address`: Physical warehouse address.
   - `created_at`: Timestamp.

4. **`purchases`**:
   - `id`: Unique primary key.
   - `medicine_id`: Foreign key referencing `medicines.id`.
   - `supplier_id`: Foreign key referencing `suppliers.id`.
   - `quantity`: Number of units purchased.
   - `purchase_price`: Cost price per unit paid to supplier.
   - `purchase_date`: Date of acquisition.
   - `created_at`: Timestamp.

5. **`sales`**:
   - `id`: Unique primary key (also acts as invoice number).
   - `medicine_id`: Foreign key referencing `medicines.id`.
   - `customer_name`: Patient or customer name.
   - `quantity`: Number of units sold.
   - `selling_price`: Retail unit price at the time of sale.
   - `total_amount`: Total transaction cost (`quantity * selling_price`).
   - `sale_date`: Date of transaction.
   - `created_at`: Timestamp.

---

## 💻 Step-by-Step Instructions to Run

### Step 1: Install Python (If not already installed)
1. Download Python 3 (version 3.10 or newer) from [python.org](https://www.python.org/downloads/).
2. **Important**: During installation on Windows, ensure the checkbox **"Add Python to PATH"** is selected.

### Step 2: Open Terminal / Command Prompt
Open Command Prompt (`cmd`), PowerShell, or Terminal on your computer.

### Step 3: Navigate to the Project Folder
```bash
cd path/to/pharmacy_inventory_system
```

### Step 4: Install Required Packages
Run the following command to install Flask:
```bash
pip install -r requirements.txt
```

### Step 5: Start the Application
Execute the following command:
```bash
python app.py
```

### Step 6: Open in Web Browser
Open your favorite web browser (Chrome, Edge, Firefox, or Safari) and navigate to:
```text
http://127.0.0.1:5000
```
Log in using:
- **Username**: `admin`
- **Password**: `admin123`

---

## 🔮 Future Enhancements

- Multi-item checkout (adding multiple different medicines onto a single invoice).
- Barcode / QR code scanning integration for quick dispensing.
- Automated email alerts to suppliers when stock hits reorder thresholds.
- Prescription file upload (PDF/Image) attached to patient sale records.
- Dark mode theme toggle.
